<!Doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css" integrity="sha384-zCbKRCUGaJDkqS1kPbPd7TveP5iyJE0EjAuZQTgFLD2ylzuqKfdKlfG/eSrtxUkn" crossorigin="anonymous">
     <link rel="stylesheet" href="<?= baseurl; ?>/asset/css/style.css">
    <title>Portopolio</title>
  </head>
  <body>
    <!--navbar-->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
 <div class="container"></div>
  <a class="navbar-brand" href="#home">Me</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ms-auto">
      <li class="nav-item active">
        <a class="nav-link" href="#home">Home <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#About">About</a>
      </li>
    <li class="nav-item">
        <a class="nav-link" href="#Project">Project</a>
        </li>
    <li class="nav-item">
        <a class="nav-link" href="#contact">Contact</a>
        </li>
        </ul>
        </div>
        </div>
      </nav>
  <!--Akhir Navbar-->
  <?php foreach($data['profile'] as $pro): ?>
  <!--Jumbotron-->
<section id="home" class="jumbotron atas text-center">
  <img src="<?= BASEURL; ?>/asset/img/b.jpg" class="rounded-circle img-thumbnail" width="250" alt="">
  <h1 class="display-4"><?= $pro['nama'];?></h1>
  <p class="lead"><?= $pro['jabatan'];?> |<?= $pro['perusahaan'];?></p>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#0099ff" fill-opacity="1" d="M0,96L48,112C96,128,192,160,288,192C384,224,480,256,576,224C672,192,768,96,864,90.7C960,85,1056,171,1152,218.7C1248,267,1344,277,1392,282.7L1440,288L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
</section>
<?php endforeach ?>
  <!--Akhir Jumbotron-->
  <!-- About -->
  <section id="About">
    <div class="row text-center mb-3">
      <h2>About Me<h2>
    </div>
</div>
    <div class="row justify-content-center fs-5 text-center">
    <?php foreach($data['about'] as $ab) : ?>
      <div class="col-4">
        <p><?= $ab['kolom1']; ?></p>
      </div>
      <div class="col-4">
        <p><?= $ab['kolom2']; ?></p>
      </div>
      <?php endforeach ?>
    </div>
  </section>
  <!-- Akhir About -->
  <!-- Project -->
<section id="projects">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>My projects</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <?php foreach($data['project' as $pro]) :?>
         <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?= BASEURL;?>/asset/img/21.jpg.jpg" class="card-img-top" alt="project1">
          <div class="card-body">
            <p class="card-text">kau yang singgah tapi tak sungguh.</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?= BASEURL;?>/asset/img/3.jpg.jpg" class="card-img-top" alt="project2">
          <div class="card-body">
            <p class="card-text">jangan terlalu berharap pada manusia.</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?= BASEURL;?>/asset/img/9.jpg.jpg" class="card-img-top" alt="project3">
          <div class="card-body">
            <p class="card-text">pada akhirnya, kecewa, sedih, dan marah,akan menjadi "ya udahlah".</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?= BASEURL;?>/asset/img/7.jpg.jpg" class="card-img-top" alt="project4">
          <div class="card-body">
            <p class="card-text">capeee,pengen ngeluhh:(.</p>
           </div>
           </div>
          </div>
        <div class="col-md-4 mb-3">
          <div class="card">
          <img src="<?= BASEURL;?>/asset/img/6.jpg.jpg" class="card-img-top" alt="project5">
          <div class="card-body">
            <p class="card-text">sok sing semangatt.</p>
           </div>
           </div>
          </div>
          <?php endforeach ?>
         </div>
       </div>
      </div>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#ccccff" fill-opacity="1" d="M0,128L48,112C96,96,192,64,288,90.7C384,117,480,203,576,224C672,245,768,203,864,160C960,117,1056,75,1152,53.3C1248,32,1344,32,1392,32L1440,32L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path></svg>
    </section>
  <!-- Akhir Project -->
 <!-- Contact -->
    <section id="contact">
      <div class="container">
        <div class="row text-center mb-3">
          <div class="col">
            <h2>Contact Me</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-6">
            <form>
              <div class="mb-3">
                <label for="name" class="form-label">Nama Lengkap</label>
                <input type="text" class="form-control" id="name" aria-describedby="name">
                </div>
                <div class="mb-3">
                  <label for="email" class="form-label">Email</label>
                  <input type="text" class="form-control" id="email" aria-describedby="email">
                </div>
                <div class="mb-3">
                  <label for="pesan" class="form-label">Pesan</label>
                  <textarea class="form-control" id="pesan" rows="3"></textarea>
                </div>
                
             <button type="submit" class="btn btn-primary">Kirim</button>
           </form>
          </div>
        </div>
      </div>
    </section>
    <!-- Akhir Contact -->
    
    <!-- Footer -->
    <footer class="bg-info text-white text-center pb-4">
      <p>Creater with <i class="bi bi-suit-heart-fill text-danger"></i> by <a href="https:/www.instagram.com/inayatidzilizzatii_"class="text-white fw-bold">inayatidzilizzatii_</a></p>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 320"><path fill="#000b76" fill-opacity="1" d="M0,128L18.5,117.3C36.9,107,74,85,111,74.7C147.7,64,185,64,222,90.7C258.5,117,295,171,332,160C369.2,149,406,75,443,85.3C480,96,517,192,554,240C590.8,288,628,288,665,256C701.5,224,738,160,775,112C812.3,64,849,32,886,69.3C923.1,107,960,213,997,229.3C1033.8,245,1071,171,1108,138.7C1144.6,107,1182,117,1218,122.7C1255.4,128,1292,128,1329,154.7C1366.2,181,1403,235,1422,261.3L1440,288L1440,320L1421.5,320C1403.1,320,1366,320,1329,320C1292.3,320,1255,320,1218,320C1181.5,320,1145,320,1108,320C1070.8,320,1034,320,997,320C960,320,923,320,886,320C849.2,320,812,320,775,320C738.5,320,702,320,665,320C627.7,320,591,320,554,320C516.9,320,480,320,443,320C406.2,320,369,320,332,320C295.4,320,258,320,222,320C184.6,320,148,320,111,320C73.8,320,37,320,18,320L0,320Z"></path></svg>
    </footer>
    <!-- Akhir Footer -->
    <!-- JavaScript-->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
  </body>
</html>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: jQuery and Bootstrap Bundle (includes Popper) -->
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous"></script>

 </body>
</html>