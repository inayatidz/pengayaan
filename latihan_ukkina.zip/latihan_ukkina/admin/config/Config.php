<?php

define('baseurl', 'http://localhost/latihan_ukkina/public');