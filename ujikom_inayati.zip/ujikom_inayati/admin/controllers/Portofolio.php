<?php 

class Portofolio extends Controller{
    public function index(){
        $this->view('portofolio/index');
    }
}