<?php
 
 class Portofolio extends Controller 
 {
     public function index()
     {
         echo "Ini controller portofolio ";
     }
 }