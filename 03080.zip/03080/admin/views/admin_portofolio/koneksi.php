<?php 
$koneksi = mysqli_connect("localhost", "root", "", "latihan_ukkina2");
// if($koneksi) echo "<h1>KONEK";